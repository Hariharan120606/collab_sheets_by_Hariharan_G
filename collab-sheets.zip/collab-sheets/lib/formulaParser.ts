import type { CellMap } from "./types";

/** Convert column letter(s) to 0-based index. A→0, B→1, Z→25, AA→26 */
export function colLetterToIndex(col: string): number {
  let idx = 0;
  for (let i = 0; i < col.length; i++) {
    idx = idx * 26 + (col.charCodeAt(i) - 64);
  }
  return idx - 1;
}

/** Convert 0-based col index to letter(s). 0→A, 25→Z, 26→AA */
export function colIndexToLetter(idx: number): string {
  let letter = "";
  let n = idx + 1;
  while (n > 0) {
    const rem = (n - 1) % 26;
    letter = String.fromCharCode(65 + rem) + letter;
    n = Math.floor((n - 1) / 26);
  }
  return letter;
}

/** Parse a cell address like "B3" → {row: 2, col: 1} (0-based) */
function parseCellRef(ref: string): { row: number; col: number } | null {
  const match = ref.match(/^([A-Z]+)(\d+)$/);
  if (!match) return null;
  return {
    col: colLetterToIndex(match[1]),
    row: parseInt(match[2], 10) - 1,
  };
}

/** Get numeric value of a cell from the cell map */
function cellNumericValue(key: string, cells: CellMap): number {
  const cell = cells[key];
  if (!cell) return 0;
  const n = parseFloat(cell.value);
  return isNaN(n) ? 0 : n;
}

/** Expand a range like "A1:C3" into an array of {row, col} */
function expandRange(
  from: string,
  to: string
): Array<{ row: number; col: number }> {
  const a = parseCellRef(from);
  const b = parseCellRef(to);
  if (!a || !b) return [];
  const result: Array<{ row: number; col: number }> = [];
  for (let r = Math.min(a.row, b.row); r <= Math.max(a.row, b.row); r++) {
    for (
      let c = Math.min(a.col, b.col);
      c <= Math.max(a.col, b.col);
      c++
    ) {
      result.push({ row: r, col: c });
    }
  }
  return result;
}

/**
 * Tokenise and evaluate a formula expression (without the leading "=").
 * Supports: numeric literals, cell references (A1), ranges in SUM (A1:B3),
 * SUM(), AVERAGE(), MIN(), MAX(), COUNT(), and +, -, *, / operators.
 */
export function evaluateFormula(
  expression: string,
  cells: CellMap,
  visitedKeys: Set<string> = new Set()
): string {
  const expr = expression.trim();

  // ── Built-in functions ───────────────────────────────────────────────────
  const fnMatch = expr.match(/^([A-Z]+)\((.+)\)$/i);
  if (fnMatch) {
    const fn = fnMatch[1].toUpperCase();
    const args = fnMatch[2];
    const values = resolveArgs(args, cells, visitedKeys);

    switch (fn) {
      case "SUM":
        return String(values.reduce((a, b) => a + b, 0));
      case "AVERAGE":
        return values.length
          ? String(values.reduce((a, b) => a + b, 0) / values.length)
          : "0";
      case "MIN":
        return values.length ? String(Math.min(...values)) : "0";
      case "MAX":
        return values.length ? String(Math.max(...values)) : "0";
      case "COUNT":
        return String(values.length);
      default:
        return `#NAME?`;
    }
  }

  // ── Arithmetic expression with cell refs ─────────────────────────────────
  // Replace cell references with their numeric values, then eval safely.
  const substituted = expr.replace(/[A-Z]+\d+/gi, (ref) => {
    const parsed = parseCellRef(ref.toUpperCase());
    if (!parsed) return "0";
    const key = `${parsed.row}:${parsed.col}`;
    if (visitedKeys.has(key)) return "0"; // circular reference guard
    const rawCell = cells[key];
    if (!rawCell) return "0";
    if (rawCell.raw.startsWith("=")) {
      const childVisited = new Set(visitedKeys);
      childVisited.add(key);
      const result = evaluateFormula(
        rawCell.raw.slice(1),
        cells,
        childVisited
      );
      return isNaN(Number(result)) ? "0" : result;
    }
    const n = parseFloat(rawCell.value);
    return isNaN(n) ? "0" : String(n);
  });

  // Safe arithmetic eval: only allow digits, operators, parens, dots, spaces
  if (/^[0-9+\-*/().% \t]+$/.test(substituted)) {
    try {
      // eslint-disable-next-line no-new-func
      const result = new Function(`"use strict"; return (${substituted})`)();
      if (typeof result === "number" && isFinite(result)) {
        // Round to avoid floating point noise
        return String(Math.round(result * 1e10) / 1e10);
      }
    } catch {
      return "#ERROR!";
    }
  }

  return "#VALUE!";
}

/** Resolve comma-separated arguments (which may include ranges) to numbers */
function resolveArgs(
  args: string,
  cells: CellMap,
  visitedKeys: Set<string>
): number[] {
  const parts = args.split(",").map((s) => s.trim());
  const values: number[] = [];

  for (const part of parts) {
    if (part.includes(":")) {
      // Range
      const [from, to] = part.split(":");
      const refs = expandRange(from.trim(), to.trim());
      for (const { row, col } of refs) {
        values.push(cellNumericValue(`${row}:${col}`, cells));
      }
    } else if (/^[A-Z]+\d+$/i.test(part)) {
      // Single cell ref
      const parsed = parseCellRef(part.toUpperCase());
      if (parsed) {
        values.push(cellNumericValue(`${parsed.row}:${parsed.col}`, cells));
      }
    } else {
      const n = parseFloat(part);
      if (!isNaN(n)) values.push(n);
    }
  }

  return values;
}

/**
 * Compute the displayed value for a raw cell input.
 * If raw starts with "=" it is treated as a formula; otherwise returned as-is.
 */
export function computeValue(raw: string, cells: CellMap, ownKey: string): string {
  if (!raw.startsWith("=")) return raw;
  const visited = new Set([ownKey]);
  try {
    return evaluateFormula(raw.slice(1), cells, visited);
  } catch {
    return "#ERROR!";
  }
}
