"use client";

import { useEffect, useRef } from "react";
import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  deleteDoc,
} from "firebase/firestore";
import { db } from "../firebase";
import type { PresenceUser } from "../types";
import { useState } from "react";

const HEARTBEAT_MS = 10_000;
const STALE_MS = 30_000;

export function usePresence(
  docId: string,
  currentUser: PresenceUser | null
) {
  const [users, setUsers] = useState<PresenceUser[]>([]);
  const heartbeatRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const cursorRef = useRef<string | null>(null);

  // Write own presence
  useEffect(() => {
    if (!currentUser) return;

    const selfRef = doc(
      db,
      "documents",
      docId,
      "presence",
      currentUser.uid
    );

    const write = () =>
      setDoc(selfRef, {
        ...currentUser,
        cursor: cursorRef.current,
        lastSeen: Date.now(),
      } satisfies PresenceUser);

    write();
    heartbeatRef.current = setInterval(write, HEARTBEAT_MS);

    return () => {
      if (heartbeatRef.current) clearInterval(heartbeatRef.current);
      deleteDoc(selfRef).catch(() => {});
    };
  }, [docId, currentUser]);

  // Subscribe to all presence docs
  useEffect(() => {
    const presenceRef = collection(db, "documents", docId, "presence");
    const unsub = onSnapshot(presenceRef, (snap) => {
      const now = Date.now();
      const active: PresenceUser[] = [];
      snap.forEach((d) => {
        const data = d.data() as PresenceUser;
        if (now - data.lastSeen < STALE_MS) active.push(data);
      });
      setUsers(active);
    });
    return unsub;
  }, [docId]);

  /** Call this when the local user moves their cursor */
  function updateCursor(key: string | null) {
    cursorRef.current = key;
    if (!currentUser) return;
    const selfRef = doc(
      db,
      "documents",
      docId,
      "presence",
      currentUser.uid
    );
    setDoc(selfRef, {
      ...currentUser,
      cursor: key,
      lastSeen: Date.now(),
    } satisfies PresenceUser).catch(() => {});
  }

  return { users, updateCursor };
}
