"use client";

import { useEffect, useState } from "react";
import {
  doc,
  onSnapshot,
  updateDoc,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "../firebase";
import type { SpreadsheetDocument } from "../types";

export function useDocument(docId: string) {
  const [document, setDocument] = useState<SpreadsheetDocument | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const ref = doc(db, "documents", docId);
    const unsub = onSnapshot(ref, (snap) => {
      if (snap.exists()) {
        setDocument({ id: snap.id, ...snap.data() } as SpreadsheetDocument);
      }
      setLoading(false);
    });
    return unsub;
  }, [docId]);

  async function renameDocument(title: string) {
    await updateDoc(doc(db, "documents", docId), {
      title,
      lastModified: Date.now(),
    });
  }

  return { document, loading, renameDocument };
}
