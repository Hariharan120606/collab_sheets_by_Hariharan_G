"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
} from "firebase/firestore";
import { db } from "../firebase";
import type { CellMap, SyncStatus } from "../types";
import { computeValue } from "../formulaParser";

export function useCells(docId: string) {
  const [cells, setCells] = useState<CellMap>({});
  const [syncStatus, setSyncStatus] = useState<SyncStatus>("idle");
  // Local shadow: avoids flicker while the server round-trip is in flight
  const localCells = useRef<CellMap>({});

  // Subscribe to all cells for this document
  useEffect(() => {
    const cellsRef = collection(db, "documents", docId, "cells");
    const unsub = onSnapshot(cellsRef, (snap) => {
      const incoming: CellMap = {};
      snap.forEach((d) => {
        const data = d.data() as { raw: string };
        incoming[d.id] = { raw: data.raw, value: data.raw }; // placeholder value
      });
      // Merge with local shadow (local wins if pending)
      const merged = { ...incoming, ...localCells.current };
      // Recompute all values now that we have the full map
      const recomputed = recomputeAll(merged);
      setCells(recomputed);
    });
    return unsub;
  }, [docId]);

  const updateCell = useCallback(
    async (key: string, raw: string) => {
      // 1. Optimistic local update
      const optimistic: CellMap = {
        ...localCells.current,
        [key]: { raw, value: raw },
      };
      const recomputed = recomputeAll(optimistic);
      localCells.current = recomputed;
      setCells(recomputed);
      setSyncStatus("saving");

      try {
        const cellRef = doc(db, "documents", docId, "cells", key);
        await setDoc(cellRef, { raw });
        // Also bump document lastModified
        await updateDoc(doc(db, "documents", docId), {
          lastModified: Date.now(),
        });
        // Clear local shadow entry — Firestore snapshot will own it now
        const next = { ...localCells.current };
        delete next[key];
        localCells.current = next;
        setSyncStatus("saved");
        setTimeout(() => setSyncStatus("idle"), 1500);
      } catch (err) {
        console.error("Cell write failed", err);
        setSyncStatus("error");
      }
    },
    [docId]
  );

  return { cells, syncStatus, updateCell };
}

/** Re-evaluate all formula cells given a complete cell map */
function recomputeAll(cells: CellMap): CellMap {
  const result: CellMap = {};
  // Two-pass: first set raw values, then compute formulas
  for (const [key, cell] of Object.entries(cells)) {
    result[key] = {
      raw: cell.raw,
      value: cell.raw.startsWith("=") ? cell.raw : cell.raw,
    };
  }
  for (const [key, cell] of Object.entries(result)) {
    if (cell.raw.startsWith("=")) {
      result[key] = {
        raw: cell.raw,
        value: computeValue(cell.raw, result, key),
      };
    }
  }
  return result;
}
