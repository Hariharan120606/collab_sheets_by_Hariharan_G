export interface SpreadsheetDocument {
  id: string;
  title: string;
  lastModified: number; // epoch ms
  createdBy: string;
  createdAt: number;
}

export interface CellData {
  /** Raw user input — may start with "=" for formulas */
  raw: string;
  /** Computed display value */
  value: string;
}

/** Keyed as "row:col", e.g. "0:0" for A1 */
export type CellMap = Record<string, CellData>;

export interface PresenceUser {
  uid: string;
  displayName: string;
  color: string;
  /** Selected cell, e.g. "0:0" */
  cursor: string | null;
  lastSeen: number;
}

export type SyncStatus = "idle" | "saving" | "saved" | "error";
