"use client";

import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import SignIn from "@/components/SignIn";
import SpreadsheetEditor from "@/components/SpreadsheetEditor";
import { useDocument } from "@/lib/hooks/useDocument";
import { useCells } from "@/lib/hooks/useCells";
import { usePresence } from "@/lib/hooks/usePresence";

export default function DocumentPage() {
  const params = useParams();
  const docId = params.id as string;
  const router = useRouter();

  const { firebaseUser, presenceUser, loading: authLoading } = useAuth();
  const { document, loading: docLoading, renameDocument } = useDocument(docId);
  const { cells, syncStatus, updateCell } = useCells(docId);
  const { users, updateCursor } = usePresence(docId, presenceUser);

  if (authLoading || docLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!firebaseUser) return <SignIn />;

  if (!document) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Document not found.</p>
          <button
            onClick={() => router.push("/")}
            className="text-emerald-600 underline text-sm"
          >
            Back to dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <SpreadsheetEditor
      docId={docId}
      docTitle={document.title}
      cells={cells}
      syncStatus={syncStatus}
      onCellChange={updateCell}
      onTitleChange={renameDocument}
      presenceUsers={users}
      onCursorChange={updateCursor}
    />
  );
}
