"use client";

import { useAuth } from "@/components/AuthProvider";
import SignIn from "@/components/SignIn";
import Dashboard from "@/components/Dashboard";

export default function HomePage() {
  const { firebaseUser, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!firebaseUser) return <SignIn />;
  return <Dashboard />;
}
