"use client";

import type { PresenceUser } from "@/lib/types";

interface Props {
  users: PresenceUser[];
  currentUid: string;
}

export default function PresenceIndicator({ users, currentUid }: Props) {
  const others = users.filter((u) => u.uid !== currentUid);

  if (others.length === 0) return null;

  return (
    <div className="flex items-center gap-1">
      <div className="flex -space-x-2">
        {others.slice(0, 5).map((u) => (
          <div
            key={u.uid}
            title={u.displayName}
            className="w-7 h-7 rounded-full border-2 border-white flex items-center justify-center text-white text-xs font-bold shadow-sm"
            style={{ backgroundColor: u.color }}
          >
            {u.displayName?.[0]?.toUpperCase()}
          </div>
        ))}
      </div>
      {others.length > 5 && (
        <span className="text-xs text-gray-500">+{others.length - 5} more</span>
      )}
    </div>
  );
}
