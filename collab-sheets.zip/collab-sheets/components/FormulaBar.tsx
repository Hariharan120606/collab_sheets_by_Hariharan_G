"use client";

import { useEffect, useRef, useState } from "react";
import { colIndexToLetter } from "@/lib/formulaParser";

interface Props {
  selectedKey: string | null;
  rawValue: string;
  onCommit: (value: string) => void;
}

function keyToLabel(key: string): string {
  const [row, col] = key.split(":").map(Number);
  return `${colIndexToLetter(col)}${row + 1}`;
}

export default function FormulaBar({ selectedKey, rawValue, onCommit }: Props) {
  const [draft, setDraft] = useState(rawValue);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setDraft(rawValue);
  }, [rawValue, selectedKey]);

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      onCommit(draft);
      inputRef.current?.blur();
    } else if (e.key === "Escape") {
      setDraft(rawValue);
      inputRef.current?.blur();
    }
  }

  return (
    <div className="flex items-center gap-0 border-b border-gray-200 bg-white">
      {/* Cell address box */}
      <div className="w-20 border-r border-gray-200 px-3 py-2 text-xs font-mono text-gray-500 flex-shrink-0 text-center">
        {selectedKey ? keyToLabel(selectedKey) : ""}
      </div>

      {/* fx label */}
      <div className="px-2 text-xs text-gray-400 italic select-none">fx</div>

      {/* Input */}
      <input
        ref={inputRef}
        type="text"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={() => {
          if (draft !== rawValue) onCommit(draft);
        }}
        disabled={!selectedKey}
        className="flex-1 px-2 py-2 text-sm font-mono focus:outline-none disabled:bg-transparent text-gray-800"
        placeholder={selectedKey ? "Enter a value or formula (e.g. =SUM(A1:B3))" : ""}
      />
    </div>
  );
}
