"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import {
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  signOut as firebaseSignOut,
  updateProfile,
  User,
} from "firebase/auth";
import { auth } from "@/lib/firebase";
import type { PresenceUser } from "@/lib/types";

/** Deterministic color from a uid */
function colorFromUid(uid: string): string {
  const palette = [
    "#E53E3E", "#DD6B20", "#D69E2E", "#38A169",
    "#3182CE", "#805AD5", "#D53F8C", "#00B5D8",
    "#2F855A", "#C05621",
  ];
  let hash = 0;
  for (let i = 0; i < uid.length; i++) hash = uid.charCodeAt(i) + (hash << 5) - hash;
  return palette[Math.abs(hash) % palette.length];
}

interface AuthContextValue {
  firebaseUser: User | null;
  presenceUser: PresenceUser | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithName: (name: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue>({
  firebaseUser: null,
  presenceUser: null,
  loading: true,
  signInWithGoogle: async () => {},
  signInWithName: async () => {},
  signOut: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setFirebaseUser(u);
      setLoading(false);
    });
    return unsub;
  }, []);

  async function signInWithGoogle() {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
  }

  async function signInWithName(name: string) {
    // Anonymous sign-in then set display name
    const { signInAnonymously } = await import("firebase/auth");
    const cred = await signInAnonymously(auth);
    await updateProfile(cred.user, { displayName: name });
    // Force re-read
    setFirebaseUser({ ...cred.user, displayName: name } as User);
  }

  async function signOut() {
    await firebaseSignOut(auth);
  }

  const presenceUser: PresenceUser | null = firebaseUser
    ? {
        uid: firebaseUser.uid,
        displayName: firebaseUser.displayName || "Anonymous",
        color: colorFromUid(firebaseUser.uid),
        cursor: null,
        lastSeen: Date.now(),
      }
    : null;

  return (
    <AuthContext.Provider
      value={{ firebaseUser, presenceUser, loading, signInWithGoogle, signInWithName, signOut }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
