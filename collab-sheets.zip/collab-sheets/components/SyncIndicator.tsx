"use client";

import type { SyncStatus } from "@/lib/types";

interface Props {
  status: SyncStatus;
}

export default function SyncIndicator({ status }: Props) {
  if (status === "idle") return null;

  const map: Record<SyncStatus, { label: string; cls: string; dot: string }> = {
    idle: { label: "", cls: "", dot: "" },
    saving: {
      label: "Saving…",
      cls: "text-amber-600 bg-amber-50 border-amber-200",
      dot: "bg-amber-400 animate-pulse",
    },
    saved: {
      label: "All changes saved",
      cls: "text-emerald-700 bg-emerald-50 border-emerald-200",
      dot: "bg-emerald-500",
    },
    error: {
      label: "Save failed — check connection",
      cls: "text-red-700 bg-red-50 border-red-200",
      dot: "bg-red-500",
    },
  };

  const { label, cls, dot } = map[status];

  return (
    <div
      className={`flex items-center gap-1.5 border rounded-full px-2.5 py-1 text-xs font-medium ${cls}`}
    >
      <span className={`w-2 h-2 rounded-full flex-shrink-0 ${dot}`} />
      {label}
    </div>
  );
}
