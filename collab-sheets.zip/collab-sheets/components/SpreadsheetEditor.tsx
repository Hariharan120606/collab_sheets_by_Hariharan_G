"use client";

import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import { useRouter } from "next/navigation";
import { colIndexToLetter } from "@/lib/formulaParser";
import type { CellMap, PresenceUser } from "@/lib/types";
import type { SyncStatus } from "@/lib/types";
import FormulaBar from "./FormulaBar";
import PresenceIndicator from "./PresenceIndicator";
import SyncIndicator from "./SyncIndicator";
import { useAuth } from "./AuthProvider";

const ROWS = 100;
const COLS = 26;
const ROW_HEIGHT = 28;
const COL_WIDTH = 100;
const ROW_HEADER_WIDTH = 48;
const COL_HEADER_HEIGHT = 28;

interface Props {
  docId: string;
  docTitle: string;
  cells: CellMap;
  syncStatus: SyncStatus;
  onCellChange: (key: string, raw: string) => void;
  onTitleChange: (title: string) => void;
  presenceUsers: PresenceUser[];
  onCursorChange: (key: string | null) => void;
}

export default function SpreadsheetEditor({
  docId,
  docTitle,
  cells,
  syncStatus,
  onCellChange,
  onTitleChange,
  presenceUsers,
  onCursorChange,
}: Props) {
  const router = useRouter();
  const { presenceUser, signOut } = useAuth();

  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState("");
  const [titleDraft, setTitleDraft] = useState(docTitle);
  const [editingTitle, setEditingTitle] = useState(false);

  const gridRef = useRef<HTMLDivElement>(null);
  const editInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { setTitleDraft(docTitle); }, [docTitle]);

  // Focus inline edit input when editing starts
  useEffect(() => {
    if (editingKey && editInputRef.current) {
      editInputRef.current.focus();
      editInputRef.current.select();
    }
  }, [editingKey]);

  const selectCell = useCallback(
    (key: string) => {
      if (editingKey && editingKey !== key) commitEdit(editingKey);
      setSelectedKey(key);
      onCursorChange(key);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [editingKey, onCursorChange]
  );

  function startEdit(key: string) {
    setEditingKey(key);
    setEditDraft(cells[key]?.raw ?? "");
  }

  function commitEdit(key: string) {
    if (editDraft !== (cells[key]?.raw ?? "")) {
      onCellChange(key, editDraft);
    }
    setEditingKey(null);
  }

  function handleCellClick(key: string) {
    if (editingKey && editingKey !== key) { commitEdit(editingKey); }
    selectCell(key);
  }

  function handleCellDoubleClick(key: string) {
    selectCell(key);
    startEdit(key);
  }

  function handleKeyDown(e: React.KeyboardEvent, row: number, col: number) {
    const key = `${row}:${col}`;

    if (editingKey === key) {
      if (e.key === "Enter") { commitEdit(key); moveSelection(row + 1, col); e.preventDefault(); }
      else if (e.key === "Escape") { setEditingKey(null); setEditDraft(""); }
      else if (e.key === "Tab") { e.preventDefault(); commitEdit(key); moveSelection(row, col + (e.shiftKey ? -1 : 1)); }
      return;
    }

    // Not editing
    if (e.key === "Enter" || e.key === "F2") { startEdit(key); e.preventDefault(); }
    else if (e.key === "Delete" || e.key === "Backspace") { onCellChange(key, ""); }
    else if (e.key === "Tab") { e.preventDefault(); moveSelection(row, col + (e.shiftKey ? -1 : 1)); }
    else if (e.key === "ArrowRight") { e.preventDefault(); moveSelection(row, col + 1); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); moveSelection(row, col - 1); }
    else if (e.key === "ArrowDown") { e.preventDefault(); moveSelection(row + 1, col); }
    else if (e.key === "ArrowUp") { e.preventDefault(); moveSelection(row - 1, col); }
    else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey) {
      // Typing starts edit with pressed char
      setEditingKey(key);
      setEditDraft(e.key);
      e.preventDefault();
    }
  }

  function moveSelection(row: number, col: number) {
    const r = Math.max(0, Math.min(ROWS - 1, row));
    const c = Math.max(0, Math.min(COLS - 1, col));
    selectCell(`${r}:${c}`);
  }

  // Determine remote cursor for a cell
  function remoteCursorFor(key: string): PresenceUser | null {
    if (!presenceUser) return null;
    return (
      presenceUsers.find((u) => u.uid !== presenceUser.uid && u.cursor === key) ?? null
    );
  }

  // Formula bar commit
  function handleFormulaBarCommit(value: string) {
    if (!selectedKey) return;
    onCellChange(selectedKey, value);
  }

  const [selRow, selCol] = selectedKey
    ? selectedKey.split(":").map(Number)
    : [-1, -1];

  return (
    <div className="flex flex-col h-screen bg-white overflow-hidden">
      {/* Top bar */}
      <div className="flex items-center gap-3 px-4 py-2 border-b border-gray-200 bg-white flex-shrink-0">
        <button
          onClick={() => router.push("/")}
          className="text-gray-400 hover:text-gray-700 transition"
          title="Back to dashboard"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
        </button>

        <div className="w-7 h-7 bg-emerald-500 rounded-md flex items-center justify-center flex-shrink-0">
          <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M3 10h18M3 6h18M3 14h18M3 18h18" />
          </svg>
        </div>

        {/* Editable title */}
        {editingTitle ? (
          <input
            autoFocus
            value={titleDraft}
            onChange={(e) => setTitleDraft(e.target.value)}
            onBlur={() => { onTitleChange(titleDraft); setEditingTitle(false); }}
            onKeyDown={(e) => {
              if (e.key === "Enter") { onTitleChange(titleDraft); setEditingTitle(false); }
              if (e.key === "Escape") { setTitleDraft(docTitle); setEditingTitle(false); }
            }}
            className="font-medium text-sm text-gray-800 border-b border-gray-300 focus:outline-none px-1"
          />
        ) : (
          <button
            onClick={() => setEditingTitle(true)}
            className="font-medium text-sm text-gray-800 hover:underline"
          >
            {docTitle}
          </button>
        )}

        <div className="flex-1" />

        <SyncIndicator status={syncStatus} />
        <PresenceIndicator users={presenceUsers} currentUid={presenceUser?.uid ?? ""} />

        {/* Own avatar */}
        <div
          className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold"
          style={{ backgroundColor: presenceUser?.color }}
          title={presenceUser?.displayName}
        >
          {presenceUser?.displayName?.[0]?.toUpperCase()}
        </div>
        <button onClick={signOut} className="text-xs text-gray-400 hover:text-gray-700 transition">
          Sign out
        </button>
      </div>

      {/* Formula bar */}
      <FormulaBar
        selectedKey={selectedKey}
        rawValue={selectedKey ? (cells[selectedKey]?.raw ?? "") : ""}
        onCommit={handleFormulaBarCommit}
      />

      {/* Grid */}
      <div ref={gridRef} className="flex-1 overflow-auto" tabIndex={-1}>
        <div
          style={{
            width: ROW_HEADER_WIDTH + COLS * COL_WIDTH,
            minHeight: COL_HEADER_HEIGHT + ROWS * ROW_HEIGHT,
            position: "relative",
          }}
        >
          {/* Column headers */}
          <div
            className="flex sticky top-0 z-20 bg-gray-50 border-b border-gray-200"
            style={{ height: COL_HEADER_HEIGHT }}
          >
            {/* Corner */}
            <div
              className="border-r border-gray-200 flex-shrink-0"
              style={{ width: ROW_HEADER_WIDTH }}
            />
            {Array.from({ length: COLS }, (_, c) => (
              <div
                key={c}
                className={`border-r border-gray-200 flex items-center justify-center text-xs font-medium flex-shrink-0 select-none ${
                  selCol === c ? "bg-emerald-100 text-emerald-800" : "text-gray-500"
                }`}
                style={{ width: COL_WIDTH, height: COL_HEADER_HEIGHT }}
              >
                {colIndexToLetter(c)}
              </div>
            ))}
          </div>

          {/* Rows */}
          {Array.from({ length: ROWS }, (_, r) => (
            <div
              key={r}
              className="flex"
              style={{ height: ROW_HEIGHT }}
            >
              {/* Row header */}
              <div
                className={`border-r border-b border-gray-200 flex items-center justify-center text-xs font-medium flex-shrink-0 select-none sticky left-0 z-10 ${
                  selRow === r ? "bg-emerald-100 text-emerald-800" : "bg-gray-50 text-gray-500"
                }`}
                style={{ width: ROW_HEADER_WIDTH }}
              >
                {r + 1}
              </div>

              {/* Cells */}
              {Array.from({ length: COLS }, (_, c) => {
                const key = `${r}:${c}`;
                const isSelected = selectedKey === key;
                const isEditing = editingKey === key;
                const remote = remoteCursorFor(key);
                const cell = cells[key];
                const isColSelected = !isSelected && selCol === c;
                const isRowSelected = !isSelected && selRow === r;

                return (
                  <div
                    key={c}
                    className={`relative border-r border-b flex-shrink-0 overflow-hidden ${
                      isSelected
                        ? "ring-2 ring-inset ring-emerald-500 z-10"
                        : isColSelected || isRowSelected
                        ? "bg-emerald-50"
                        : "bg-white"
                    }`}
                    style={{ width: COL_WIDTH, height: ROW_HEIGHT }}
                    onClick={() => handleCellClick(key)}
                    onDoubleClick={() => handleCellDoubleClick(key)}
                    onKeyDown={(e) => handleKeyDown(e, r, c)}
                    tabIndex={isSelected ? 0 : -1}
                  >
                    {/* Remote cursor badge */}
                    {remote && (
                      <div
                        className="absolute top-0 right-0 w-2 h-2 rounded-bl"
                        style={{ backgroundColor: remote.color }}
                        title={remote.displayName}
                      />
                    )}

                    {isEditing ? (
                      <input
                        ref={editInputRef}
                        value={editDraft}
                        onChange={(e) => setEditDraft(e.target.value)}
                        onKeyDown={(e) => handleKeyDown(e, r, c)}
                        onBlur={() => commitEdit(key)}
                        className="w-full h-full px-1.5 text-sm font-mono focus:outline-none bg-white"
                        style={{ minWidth: COL_WIDTH }}
                      />
                    ) : (
                      <span
                        className={`block px-1.5 text-sm leading-7 truncate select-none ${
                          cell?.value?.startsWith("#") ? "text-red-500" : "text-gray-800"
                        }`}
                      >
                        {cell?.value ?? ""}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
