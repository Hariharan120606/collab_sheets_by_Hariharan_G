"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  collection,
  onSnapshot,
  addDoc,
  deleteDoc,
  doc,
  query,
  orderBy,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "./AuthProvider";
import type { SpreadsheetDocument } from "@/lib/types";

function timeAgo(ms: number): string {
  const diff = Date.now() - ms;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export default function Dashboard() {
  const { presenceUser, signOut } = useAuth();
  const [docs, setDocs] = useState<SpreadsheetDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const q = query(collection(db, "documents"), orderBy("lastModified", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      setDocs(
        snap.docs.map((d) => ({ id: d.id, ...d.data() } as SpreadsheetDocument))
      );
      setLoading(false);
    });
    return unsub;
  }, []);

  async function createDocument() {
    if (!presenceUser) return;
    setCreating(true);
    const docRef = await addDoc(collection(db, "documents"), {
      title: "Untitled spreadsheet",
      lastModified: Date.now(),
      createdBy: presenceUser.displayName,
      createdAt: Date.now(),
    });
    setCreating(false);
    router.push(`/document/${docRef.id}`);
  }

  async function removeDocument(e: React.MouseEvent, id: string) {
    e.stopPropagation();
    if (!confirm("Delete this document?")) return;
    await deleteDoc(doc(db, "documents", id));
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M3 10h18M3 6h18M3 14h18M3 18h18" />
            </svg>
          </div>
          <span className="font-semibold text-gray-900">CollabSheets</span>
        </div>
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold"
            style={{ backgroundColor: presenceUser?.color }}
            title={presenceUser?.displayName}
          >
            {presenceUser?.displayName?.[0]?.toUpperCase()}
          </div>
          <span className="text-sm text-gray-600 hidden sm:block">{presenceUser?.displayName}</span>
          <button
            onClick={signOut}
            className="text-sm text-gray-500 hover:text-gray-800 transition"
          >
            Sign out
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-800">My Spreadsheets</h2>
          <button
            onClick={createDocument}
            disabled={creating}
            className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg px-4 py-2 text-sm font-medium transition disabled:opacity-50"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            {creating ? "Creating…" : "New spreadsheet"}
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-xl border border-gray-200 h-28 animate-pulse" />
            ))}
          </div>
        ) : docs.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                  d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7" />
              </svg>
            </div>
            <p className="text-gray-500 text-sm">No spreadsheets yet. Create one to get started!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {docs.map((d) => (
              <div
                key={d.id}
                onClick={() => router.push(`/document/${d.id}`)}
                className="group bg-white rounded-xl border border-gray-200 p-5 cursor-pointer hover:border-emerald-400 hover:shadow-sm transition"
              >
                {/* Spreadsheet thumbnail icon */}
                <div className="w-full h-16 bg-emerald-50 rounded-lg mb-4 flex items-center justify-center">
                  <svg className="w-8 h-8 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                      d="M3 10h18M3 6h18M3 14h18M3 18h18M9 6v12" />
                  </svg>
                </div>
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-800 text-sm truncate">{d.title}</p>
                    <p className="text-xs text-gray-400 mt-1">
                      {timeAgo(d.lastModified)} · {d.createdBy}
                    </p>
                  </div>
                  <button
                    onClick={(e) => removeDocument(e, d.id)}
                    className="opacity-0 group-hover:opacity-100 transition ml-2 text-gray-400 hover:text-red-500"
                    title="Delete"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
